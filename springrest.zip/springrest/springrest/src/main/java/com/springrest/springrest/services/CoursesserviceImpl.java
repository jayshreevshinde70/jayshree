package com.springrest.springrest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.CourseDao;
import com.springrest.springrest.entities.Course;

@Service
public class CoursesserviceImpl implements CoursesService {

	@Autowired
	private CourseDao courseDao;
	//List<Course> list;
	
	public CoursesserviceImpl() {
		//list=new ArrayList<>();
		//list.add(new Course(145,"java core course","Basic of java"));
		//list.add(new Course(4343,"spring core course","basic of spring"));
	}

	@Override
	public List<Course> getCourses() {
		
		return courseDao.findAll();
	}

	@SuppressWarnings("deprecation")
	@Override
	public Course getcourse(long courseId) {
		
		//Course c=null;
		//for(Course course:list)
		//{
			//if(course.getId()==courseId) {
			//	c=course;
			//	break;
			//}
		//}
		return courseDao.getOne(courseId);
	}

	@Override
	public Course addcourse(Course course) {
		//list.add(course);
		courseDao.save(course);
		return course;
	}

	@Override
	public Course updatecourse(Course course) {
		/*
		 * list.forEach(e->{ if(e.getId()==course.getId()) {
		 * e.setTitle(course.getTitle()); e.setDescription(course.getDescription()); }
		 * });
		 */
		courseDao.save(course);
	    return course;
	}

	@Override
	public void deletecourse(long parsLong) {
		//list=this.list.stream().filter(e->e.getId()!=parsLong).collect(Collectors.toList());
		@SuppressWarnings("deprecation")
		Course entity= courseDao.getOne(parsLong);
		courseDao.delete(entity);
	}

	

}
