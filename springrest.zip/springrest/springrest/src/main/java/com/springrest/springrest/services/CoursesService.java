package com.springrest.springrest.services;

import java.util.List;

import com.springrest.springrest.entities.Course;

public interface CoursesService {
	
public List<Course> getCourses();
public Course getcourse(long courseId);
public Course addcourse(Course course);
public Course updatecourse(Course course);
public void deletecourse(long courseId);
}
